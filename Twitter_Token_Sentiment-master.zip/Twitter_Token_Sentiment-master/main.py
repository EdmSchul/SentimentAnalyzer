#Twitter sentiment analyzer
#Edmund Schultz

# Links used to write this program:
#https://github.com/DamienBonello/Twitter_Token_Sentiment
#https://www.analyticsvidhya.com/blog/2021/06/twitter-sentiment-analysis-a-nlp-use-case-for-beginners/

import tweepy
import pandas as pd
from textblob import TextBlob
from nltk.sentiment import SentimentIntensityAnalyzer
#assign the sentiment analyzer to a variable to make it usable
sia = SentimentIntensityAnalyzer()

#this is the client code plugged into a usable variable as well
client = tweepy.Client("AAAAAAAAAAAAAAAAAAAAACb3ZQEAAAAADuFndZvuRhzqYZfxYOKN5IwPPAQ%3DSbLH6UNsBRVJJDDWqX6LnuDBS2Mrh2Xpe1TcfMeWVOrB8ZfVBi")

#Gather the user input to prepare for a search
name = input("What Token do you wish to analyse? ")
#filter out any tweets that are in different languages and are retweets
query = f"#{name} lang:en -is:retweet"

#set up an array to store the future data pulled from twitter 
tweet_info_ls = []

#Runs the data found through tweepy's paginator, looking for recent tweets that match the query in public metrics. the results are limited as well
for tweet in tweepy.Paginator(client.search_recent_tweets, query, tweet_fields=["public_metrics"],
                              expansions='author_id', max_results=100).flatten(limit=1000):
    #checks to see how well the tweet did in likes
    if tweet.public_metrics['like_count'] > 1:
        #gathers the tweet info to display and also runs the tweet through the sentiment analyzer and textblob
        tweet_info = {
            'Tweet': tweet.text,
            'Likes': tweet.public_metrics['like_count'],
            'RTs': tweet.public_metrics['retweet_count'],
            'Vader Subjectivity': sia.polarity_scores(tweet.text),
            'Subjectivity': round(TextBlob(tweet.text).sentiment.subjectivity, 5),
            'Polarity': round(TextBlob(tweet.text).sentiment.polarity, 5),
        }
        #once the info is gathered, append it to a new variable
        tweet_info_ls.append(tweet_info)

# create dataframe from the extracted records
tweets_df = pd.DataFrame(tweet_info_ls)
pd.set_option("colheader_justify", "center")

# Build simple sentiment analysis
Weighted_Polarity = round(tweets_df['Polarity'].sum() / len(tweet_info_ls), 5)
# Build simple subjectivity analysis
Weighted_Subjectivity = round(tweets_df['Subjectivity'].sum() / len(tweet_info_ls), 5)
# export the data into an html format
table = tweets_df.to_html(index=True, classes='mystyle')

#Testing the polarity. anything over 0.5 is a 1 and therefore positive. otherwise it is classified as negative
if Weighted_Polarity == 1 > 0.5:
    Polarity = "Positive"
else:
    Polarity = "Negative"
#Testing the subjectivity. anything over 0.5 is a 1 and therefore biased. otherwise it is classified as not so biased
if Weighted_Subjectivity == 1 > 0.5:
    Subjectivity = "Biased"
else:
    Subjectivity = "Not so Biased"

# setting up the html user interface
html_string = '''
<html>
  <head><title>HTML Pandas Dataframe with CSS</title></head>
  <link rel="stylesheet" type="text/css" href="df_style.css"/>
  <body>
  <div class='test'>
    <h1>Polarity: {Weighted_Polarity} - {Polarity}</h1>
  </div>
  <div class='test'>
    <h1>Subjectivity: {Weighted_Subjectivity} - {Subjectivity}</h1>
  </div>
    {table}
  </body>
</html>
'''.format(**locals())

# # Outputting the html file itself
with open('tweets.html', 'w', encoding="utf-8") as f:
    f.write(html_string)
