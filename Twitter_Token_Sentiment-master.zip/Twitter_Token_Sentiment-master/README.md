# Twitter_Token_Sentiment
Basic Sentiment Analysis of Recent Tweets on a desired Input.

When you run the code you will prompted to input what you wish to have analysed. This can be anything. 

NOTE: There is no need to add '#' as this is already included in the code, you simply write as plain text like you would on twitter. 

Prequisites needed for this code;  

Tweepy, TextBlob, Pandas & NLTK Sentiment (in Testing in this project).

Will update how to install all the packages in due course.

Once the code is executed, it should create an HTML file within the directory where the code is saved. Open the file to view the results which includes the pandas dataframe containing all the tweets.
